#!/bin/bash

default_path_to_repo="code.mariadb.com/mariadb-maxscale/1.1"
path_to_repo="${1:-$default_path_to_repo}"

maxdir="/usr/local/mariadb-maxscale-setup"

if command -v zypper &>/dev/null; then
	# it is SUSE
	#/etc/SuSE-release is deprecated, so we prefer /etc/os-release
	if [[ -e /etc/os-release ]] ; then
		IFS=. read -r distro_version minor < <(
			awk -F' *= *' '$1=="VERSION_ID"{gsub(/"/,"",$2); print $2 }' /etc/os-release
		)
	else
		#SLES 11 doesn't have /etc/os-release
		distro_version=$(awk -F' *= *' '$1=="VERSION"{print $2}' /etc/SuSE-release)
	fi

	if [[ ! $distro_version ]]; then
		echo "[ERROR] couldn't determine OS version. Aborting." >&2
		exit 1
	fi

	# this distro_name variable is not actually used right now?
	if ((distro_version==13)); then
		# we have opensuse only for version 13 (should be fixed later)
                distro_name="opensuse"
	else
                distro_name="sles"
        fi

	sed "s|####path_to_repo####|$path_to_repo|g" \
	    "$maxdir/maxscale.repo.suse$distro_version.template" \
	    > /etc/zypp/repos.d/maxscale.repo
	#rpm --import "$path_to_repo/Maxscale-GPG-KEY.public"

elif command -v yum &>/dev/null; then
	# there is yum here
	distro_name="rhel" #rhel covers RHEL and CentOS
	if [[ -e /etc/os-release ]] && grep -q '^ID=.*fedora' /etc/os-release; then
		distro_name="fedora"
	fi

	sed -e "s|####path_to_repo####|$path_to_repo|g" \
	    -e  "s|####distro_name####|$distro_name|g" \
	    "$maxdir"/maxscale.repo.template \
	    > /etc/yum.repos.d/maxscale.repo

elif command -v apt-get &>/dev/null ; then
	# there is apt-get here
	if [[ $(lsb_release -sd) = Ubuntu* ]]; then 
		distro_name="ubuntu"
	else 
        	distro_name="debian"
	fi
	distro_codename=$(lsb_release -sc)
	
	sed -e "s|####path_to_repo####|$path_to_repo|" \
	    -e "s|####distro_name####|$distro_name|" \
	    -e "s|####distro_codename####|$distro_codename|" \
	    "$maxdir"/maxscale.list.template \
	    > /etc/apt/sources.list.d/maxscale.list

	apt-key add "$maxdir/Maxscale-GPG-KEY.public"
else
	# some unknown Linux, apparently...
	echo "[ERROR] unable to identify operating system. Aborting. Please report this error.">&2 
	exit 1
fi
